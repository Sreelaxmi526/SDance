﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Net;
using System.Net.Mail;
using System.Web.Mvc;
using DanceStudioProject.Models;
using DanceStudioProject.ViewModels;


namespace DanceStudioProject.Controllers
{
    public class CandidatesController : Controller
    {
        private Training_12DecMumbaiEntities1 db = new Training_12DecMumbaiEntities1();
       // private static int Count = 35;
        // GET: Candidates
        public ActionResult Index()
        {
            return View();
        }


        public ActionResult danceTypes()
        {

            return View();
        }

        [HttpPost]
        public ActionResult danceTypes(string dancetype)
        {
                Session["danceType"] = dancetype;
            return RedirectToAction("showChoreographers", "Candidates");
        }

        [AcceptVerbs(HttpVerbs.Get)]
        public ActionResult showChoreographers()
        {
            string danceType = Session["danceType"].ToString();
            List<ChoreographerViewModel> CustomerVMlist = new List<ChoreographerViewModel>(); // to hold list of Customer and order details
            var customerlist =
             (from a in db.DBookChoreographers
              join b in db.DanceClassRooms
                  on a.ClassRoomId equals b.ClassRoomId
              join c in db.Candidates on a.userID equals c.userID
              join d in db.Candidates on b.choreographerId equals d.userID
              where a.DanceType == danceType 
              select new
              {
                d.username,
                  d.City,
                  d.MobileNumber,
                  d.Email,
                  a.DanceType,
                  

              }).Distinct();

            //query getting data from database from joining two tables and storing data in customerlist

            foreach (var item in customerlist)

            {
                ChoreographerViewModel objcvm = new ChoreographerViewModel(); // ViewModel

                objcvm.username = item.username;

                objcvm.MobileNumber = item.MobileNumber;

                objcvm.Email = item.Email;

                objcvm.DanceType = item.DanceType;

                objcvm.City = item.City;

                CustomerVMlist.Add(objcvm);

            }

            //Using foreach loop fill data from custmerlist to List<CustomerVM>.

            return View(CustomerVMlist); //List of CustomerVM (ViewModel)

        }


        
        public ActionResult bookChoreographer(string selectedChoreographer, string dancetype)
        {
            
            Session["selectedChoreographer"] = selectedChoreographer;
            Session["danceType"] = dancetype;
            return View();
        }

        [HttpPost]
        public ActionResult bookChoreographer(ChoreographerViewModel bookChoreographer)
        {


            if (ModelState.IsValid)
            {
                string msg = "booking date b/w current date year to last date year(2020) ";
                DateTime bd = Convert.ToDateTime(bookChoreographer.BookingDate);
                var startdate = DateTime.Now;
                var enddate = DateTime.ParseExact("31/12/2020", "dd/MM/yyyy", null);
                if (bd.Date > startdate.Date && bd.Date <= enddate.Date)
                {
                    //var bookeddate = bookChoreographer.BookingDate.ToString("d");
                    string chname = Session["selectedChoreographer"].ToString();


                    List<ChoreographerViewModel> CustomerVMlist = new List<ChoreographerViewModel>(); 
                    var res = db.Candidates.Where(a => a.username == chname).ToList();

                    if (res.Count == 0)
                    {
                        if (saveBookingDetails(bookChoreographer))
                        {
                            return Content("<html><head><script>alert('Successfully Booked'); window.location.href = '/Candidates/Index'</script></head></html>");
                            //return RedirectToAction("Index", "Users");
                        }
                    }
                    else
                    {
                        if (res.Count < 60)
                        {
                            if (res[0].City == bookChoreographer.City /*&& (res[0].BookingDate == bookChoreographer.BookingDate)*/)
                            {
                                if (saveBookingDetails(bookChoreographer))
                                {
                                    return Content("<html><head><script>alert('Successfully Booked'); window.location.href = '/Candidates/Index'</script></head></html>");
                                    //return RedirectToAction("Index", "Users");
                                }
                            }
                            else if (res[0].City != bookChoreographer.City /*&& (res[0].BookingDate == bookChoreographer.BookingDate)*/)
                            {
                                if (saveBookingDetails(bookChoreographer))
                                {
                                    return Content("<html><head><script>alert('Successfully Booked'); window.location.href = '/Candidates/Index'</script></head></html>");
                                    //return RedirectToAction("Index", "Users");
                                }
                            }
                            ModelState.AddModelError("choreographername", "Selected Choreographer has Booking on Same Date in different Location");
                        }
                        else
                        {
                            ModelState.AddModelError("choreographername", "the selected Choreographer has limited bookings ,Only 3 Booking can be done per a day");
                        }
                    }
                }
                else
                {
                    ModelState.AddModelError("BookingDate", msg);
                }
            }
            return View();
        }


        public ActionResult bookingDetails()
        {
            string user = Session["username"].ToString();
            List<ChoreographerViewModel> CustomerVMlist = new List<ChoreographerViewModel>(); // to hold list of Customer and order details
            var customerlist =
             (from a in db.DBookChoreographers
              join b in db.DanceClassRooms
                  on a.ClassRoomId equals b.ClassRoomId
              join c in db.Candidates on a.userID equals c.userID
              join d in db.Candidates on b.choreographerId equals d.userID
              where c.username == user
              select new { 
                  d.username,
                  d.City,
                  d.MobileNumber,
                  d.Email,
                  a.DanceType

              }).ToList();

            //query getting data from database from joining two tables and storing data in customerlist

            foreach (var item in customerlist)

            {
                ChoreographerViewModel objcvm = new ChoreographerViewModel(); // ViewModel

                objcvm.username = item.username;

                objcvm.MobileNumber = item.MobileNumber;

                objcvm.Email = item.Email;

                objcvm.DanceType = item.DanceType;

                objcvm.City = item.City;

                CustomerVMlist.Add(objcvm);

            }

            //Using foreach loop fill data from custmerlist to List<CustomerVM>.

            return View(CustomerVMlist);
        }

      
        public bool saveBookingDetails(ChoreographerViewModel bookChoreographer)
        {
            bool isSaved = false;
              //  int Count = 35;
            try
            {

               // string chname = Session["username"].ToString();
                //  bookChoreographer.username = Session["username"].ToString();
                bookChoreographer.username = Session["selectedChoreographer"].ToString();
                bookChoreographer.name = Session["username"].ToString();

                string chname= Session["selectedChoreographer"].ToString(); 
                ChoreographerViewModel attvm = new ChoreographerViewModel();
                
                bookChoreographer.username = Session["selectedChoreographer"].ToString();
                DBookChoreographer dBookChoreographer = new DBookChoreographer();
                dBookChoreographer.DanceType = bookChoreographer.DanceType;
                dBookChoreographer.BookingDate = bookChoreographer.BookingDate;
                var userId = (from a in db.Candidates.Where(a => a.username == bookChoreographer.name) select  ( a.userID )).FirstOrDefault();                     
                dBookChoreographer.userID = Convert.ToInt32(userId);

               var classRoomId = (from a in db.Candidates join b in db.DanceClassRooms on a.userID equals b.choreographerId where a.username == chname select (b.ClassRoomId )).ToList();

                var Id = classRoomId.Last();
               dBookChoreographer.ClassRoomId = Convert.ToInt32(Id);

                //   changeAttendanceStatus.userName = attvm[i].isPresent;
                db.DBookChoreographers.Add(dBookChoreographer);
                db.SaveChanges();

                
                DanceClassRoom danceClassRoom = new DanceClassRoom();
               if( bookChoreographer.BookingType=="Studio")
                {
                    danceClassRoom.RoomNumber = 1;
                    danceClassRoom.EntriesCount = Id;
                }
               else
                {
                    danceClassRoom.RoomNumber = null;
                    Id=Id--;
                }
                danceClassRoom.BookingType = bookChoreographer.BookingType;
                var choreographerId = (from a in db.Candidates.Where(a => a.username == bookChoreographer.username) select (a.userID)).FirstOrDefault();
                danceClassRoom.choreographerId = Convert.ToInt32(choreographerId);
               
                db.DanceClassRooms.Add(danceClassRoom);
                sendEmail(bookChoreographer.Email, "Choreographer booked Successfully", $"Choreographer {bookChoreographer.username} booking done successfully!!!");
                db.SaveChanges();


                isSaved = true;
                return isSaved;
            }
            catch(Exception )
            {
                return isSaved;
            }
         
          
        }
        public void sendEmail(string receiver, string subject, string message)
        {

            string email1 = "sreelaxmi.kancharla@capgemini.com";
            //string email1 = "prabhakar.heart007@gmail.com";
            string password = "$riDaddy1234";

            MailMessage mail = new MailMessage();
            SmtpClient SmtpServer = new SmtpClient("smtp.outlook.com");
            //SmtpClient SmtpServer = new SmtpClient("smtp.gmail.com");

            mail.From = new MailAddress(email1, "Choreogragher");
            mail.To.Add(receiver);
            mail.Subject = subject;

            string body = message;
            mail.Body = body;
            mail.IsBodyHtml = true;
            //SmtpServer.UseDefaultCredentials = false;
            SmtpServer.Port = 25;
            SmtpServer.Credentials = new System.Net.NetworkCredential(email1, password);
            SmtpServer.EnableSsl = true;
            SmtpServer.Send(mail);
        }

    }

 }



    
