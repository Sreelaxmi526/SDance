﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DanceStudioProject.Models;

namespace DanceStudioProject.Controllers
{
    public class AccountController : Controller
    {
        private Training_12DecMumbaiEntities1 db = new Training_12DecMumbaiEntities1();
        // GET: Account
        public ActionResult Index()
        {
            return View();
        }


        public ActionResult Register()
        {
            return View();
        }

        // POST: Users/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        //[ValidateAntiForgeryToken]
        public ActionResult Register([Bind(Include = "username,password,Email,Gender,DOB,City,MobileNumber,RoleName")] Candidate user)
        {
            if (ModelState.IsValid)
            {
                string msg = "Invalid Date of Birth,enter the DOB B/W 1980-2012";
                DateTime dob = Convert.ToDateTime(user.DOB);
                var startdate = DateTime.ParseExact("01/01/1980", "dd/MM/yyyy", null);
                var enddate = DateTime.ParseExact("31/12/2012", "dd/MM/yyyy", null);
                if (dob.Date > startdate.Date && dob.Date <= enddate.Date)
                {
                    db.Candidates.Add(user);
                    //Candidate newuser = new Candidate() { username = user.username, password = user.password };
                    //db.Candidates.Add(newuser);
                    db.SaveChanges();
                    return Content("<html><head><script>alert('Successfully Registered'); window.location.href = '/Account/Login'</script></head></html>");
                    // return RedirectToAction("Login");
                }
                ModelState.AddModelError("dob", msg);
            }
            return View(user);
        }

        public ActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Login(Candidate user)
        {
            if (user.username != null)
            {
                var res = db.Candidates.Where(a => a.username == user.username).SingleOrDefault();
                if (res != null)
                {
                    if (res.password == user.password)
                    {
                        Session["isLogin"] = "true";
                        Session["username"] = res.username;
                        Session["UserId"] = res.username;
                        Session["Usertype"] = res.RoleName;
                        return RedirectToAction("Index", "Candidates");
                    }
                    else
                    {
                        ModelState.AddModelError("password", "password not match");
                    }
                }
                else
                {
                    ModelState.AddModelError("username", "username not exist");
                }
            }
            return View();
        }

        public ActionResult Logout()
        {
            Session.RemoveAll();
            Session.Abandon();
            Session.Clear();
            return Content("<html><head><script> window.history.forward(1); window.location.href = '/Account/Login'</script></head></html>");
        }



    }
}