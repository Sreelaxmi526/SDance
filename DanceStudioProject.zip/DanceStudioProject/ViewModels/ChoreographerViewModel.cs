﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using DanceStudioProject.Models;


namespace DanceStudioProject.ViewModels
{
    public class ChoreographerViewModel
    {
        public Candidate Candidate { get; set; }

        //[Display(Name = "ChoreographerName")]

        public string username { get; set; } // Candidate

        public string name { get; set; }
        public string Email { get; set; } // Candidate

        public string MobileNumber { get; set; } // Candidate
        
        public string DanceType { get; set; } // DBookChoreographer

        public string City { get; set; } //

        public string BookingType { get; set; } //DBookChoreographer

     
        public int BookingId { get; set; }
        public System.DateTime BookingDate { get; set; }

        public string BookingStatus { get; set; }

        public string BookingSlot { get; set; }
    }
}